<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* catch.html.twig */
class __TwigTemplate_3bff4aff501fa30e8f4cd94ce921b6855890189c262a4bbe49d832d8e6c72f35 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "catch.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "catch.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "catch";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "\t<style type=\"text/css\">
\t\tbody{
\t\t\tfont-family: 'Roboto', sans-serif;
\t\t}
\t\ttable.catch-table{
\t\t\t
\t\t}
\t\ttable.catch-table thead tr th{
\t\t\tbackground-color: #0074d9;
\t\t\tcolor: #fff;
\t\t\tborder-bottom: 3px solid #ffb700;
\t\t}
\t\ttable.catch-table th, table.catch-table td{
\t\t\tpadding: 8px 16px;
\t\t\ttext-align: center;
\t\t}
\t\ttable.catch-table thead tr th:first-child{
\t\t\tborder-top-left-radius: 8px;
\t\t}
\t\ttable.catch-table thead tr th:last-child{
\t\t\tborder-top-right-radius: 8px;
\t\t}
\t\ttable.catch-table tbody tr:nth-child(even){
\t\t\tbackground-color: #fff;
\t\t}
\t\ttable.catch-table tbody tr:nth-child(odd){
\t\t\tbackground-color: rgba(0,116,217,0.1);
\t\t}
\t\t.dataTables_wrapper .dataTables_paginate .paginate_button{
\t\t\tborder: 0 !important;
\t\t\tbackground: transparent;
\t\t\tpadding: 4px 12px;
\t\t\tborder-radius: 8px;
\t\t}
\t\t.dataTables_wrapper .dataTables_paginate .paginate_button.current{
\t\t\tborder: 0;
\t\t\tbackground: rgba(0,116,217,0.3) !important;
\t\t}
\t\t.dataTables_wrapper .dataTables_paginate .paginate_button:hover, .dataTables_wrapper .dataTables_paginate .paginate_button .current:hover{
\t\t\tcolor: #000000 !important;
\t\t\tfont-size: 16px;
\t\t\tborder: 0 !important;
\t\t\tbackground: rgba(0,116,217,0.3) !important;
\t\t}
\t\t.dataTables_length select{
\t\t\tborder-radius: 8px;
\t\t\tmargin-right: 16px;
\t\t\tpadding: 2px 8px;
\t\t}
\t\t.dataTables_wrapper .dataTables_filter input{
\t\t\tborder: 1px solid #ccc;
\t\t\tbox-shadow: inset 0 1px 3px #F7F7F7;
\t\t\tpadding: 2px 8px;
\t\t\tborder-radius: 8px;
\t\t}
\t\t.card{
\t\t\tpadding: 1.5rem;
\t\t\tbox-shadow:  0px 3px 6px rgba(0,0,0,0.3);
\t\t\tborder-radius: 8px;
\t\t}
\t</style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 70
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 71
        echo "\t<script type=\"text/javascript\">
\t\tvar myApp = {
\t\t\tloadData: () => {
\t\t\t\t\$.ajax({            
\t\t            type: \"GET\",
\t\t            url: \"";
        // line 76
        echo twig_escape_filter($this->env, twig_constant("App\\Controller\\MainController::BASE_URL"), "html", null, true);
        echo "public/data\",
\t\t            success: function(dataReturn){
\t\t            \tif( Array.isArray(dataReturn) ){
\t\t            \t\tvar tbody = '';
\t\t            \t\tfor(let i=0; i<dataReturn.length; i++){
\t\t            \t\t\tlet row = dataReturn[i];
\t\t            \t\t\ttbody += `\t<tr>
\t\t            \t\t\t\t\t\t\t<td>\${(i+1)}</td>
\t\t            \t\t\t\t\t\t\t<td>\${row.id}</td>
\t\t            \t\t\t\t\t\t\t<td>\${row.date}</td>
\t\t            \t\t\t\t\t\t\t<td class=\"text-right\">\${ accounting.formatMoney(row.total, \"AUD \", 2, \".\", \",\") }</td>
\t\t            \t\t\t\t\t\t\t<td class=\"text-right\">\${ accounting.formatMoney(row.avgPrice, \"AUD \", 2, \".\", \",\") }</td>
\t\t            \t\t\t\t\t\t\t<td>\${row.uniqueItem}</td>
\t\t            \t\t\t\t\t\t\t<td>\${row.state}</td>
\t\t            \t\t\t\t\t\t</tr>`;
\t\t            \t\t}
\t\t            \t}
\t\t                
\t\t\t\t\t\t\$(\"#tableOrder > tbody\").html(tbody);
\t\t\t\t\t\t\$(\"#tableOrder\").DataTable();
\t\t            \t
\t\t            },
\t\t            error: function(msg){
\t\t                alert(\"Some error occured, please try again later.\")
\t\t            }
\t\t        });
\t\t\t},
\t\t\tinit: () => {
\t\t\t\tmyApp.loadData();

\t\t\t\t\$(\"button[name='btnDownload']\").click( (e) => {
\t\t\t\t\tlet format = \$(e.target).data(\"fmt\");
\t\t\t\t\twindow.open( \"";
        // line 108
        echo twig_escape_filter($this->env, twig_constant("App\\Controller\\MainController::BASE_URL"), "html", null, true);
        echo "public/download?format=\"+ format , \"_blank\");
\t\t\t\t});
\t\t\t}
\t\t}
\t\t\$(document).ready( () => {
\t\t\tmyApp.init();
\t\t});
\t</script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 118
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 119
        echo "\t<div class=\"container-fluid p-3\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-lg-9\">
\t\t\t\t<div class=\"card\">
\t\t\t\t\t<h3>catch.com.au test</h3>
\t\t\t\t\t
\t\t\t\t\t<table class=\"table catch-table\" id=\"tableOrder\">
\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<th>No.</th>
\t\t\t\t\t\t\t\t<th>Order ID</th>
\t\t\t\t\t\t\t\t<th>Date Time</th>
\t\t\t\t\t\t\t\t<th>Total Order Value</th>
\t\t\t\t\t\t\t\t<th>Avg Unit Price</th>
\t\t\t\t\t\t\t\t<th>Unit Count</th>
\t\t\t\t\t\t\t\t<th>Customer State</th>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</thead>
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t
\t\t\t\t\t\t</tbody>
\t\t\t\t\t</table>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"col-lg-3\">
\t\t\t\t<div class=\"card\">
\t\t\t\t\t<h3 class=\"text-center border-bottom\">Get Data</h3>
\t\t\t\t\t<button name=\"btnDownload\" data-fmt=\"csv\" class=\"btn btn-primary m-1\">CSV</button>
\t\t\t\t\t<button name=\"btnDownload\" data-fmt=\"xml\" class=\"btn btn-primary m-1\">XML</button>
\t\t\t\t\t<button name=\"btnDownload\" data-fmt=\"json\" class=\"btn btn-primary m-1\">JSON</button>
\t\t\t\t</div>
\t\t\t</div>

\t\t</div>
\t</div>
\t
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "catch.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  215 => 119,  208 => 118,  192 => 108,  157 => 76,  150 => 71,  143 => 70,  75 => 7,  68 => 6,  55 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}catch{% endblock %}


{% block stylesheets %}
\t<style type=\"text/css\">
\t\tbody{
\t\t\tfont-family: 'Roboto', sans-serif;
\t\t}
\t\ttable.catch-table{
\t\t\t
\t\t}
\t\ttable.catch-table thead tr th{
\t\t\tbackground-color: #0074d9;
\t\t\tcolor: #fff;
\t\t\tborder-bottom: 3px solid #ffb700;
\t\t}
\t\ttable.catch-table th, table.catch-table td{
\t\t\tpadding: 8px 16px;
\t\t\ttext-align: center;
\t\t}
\t\ttable.catch-table thead tr th:first-child{
\t\t\tborder-top-left-radius: 8px;
\t\t}
\t\ttable.catch-table thead tr th:last-child{
\t\t\tborder-top-right-radius: 8px;
\t\t}
\t\ttable.catch-table tbody tr:nth-child(even){
\t\t\tbackground-color: #fff;
\t\t}
\t\ttable.catch-table tbody tr:nth-child(odd){
\t\t\tbackground-color: rgba(0,116,217,0.1);
\t\t}
\t\t.dataTables_wrapper .dataTables_paginate .paginate_button{
\t\t\tborder: 0 !important;
\t\t\tbackground: transparent;
\t\t\tpadding: 4px 12px;
\t\t\tborder-radius: 8px;
\t\t}
\t\t.dataTables_wrapper .dataTables_paginate .paginate_button.current{
\t\t\tborder: 0;
\t\t\tbackground: rgba(0,116,217,0.3) !important;
\t\t}
\t\t.dataTables_wrapper .dataTables_paginate .paginate_button:hover, .dataTables_wrapper .dataTables_paginate .paginate_button .current:hover{
\t\t\tcolor: #000000 !important;
\t\t\tfont-size: 16px;
\t\t\tborder: 0 !important;
\t\t\tbackground: rgba(0,116,217,0.3) !important;
\t\t}
\t\t.dataTables_length select{
\t\t\tborder-radius: 8px;
\t\t\tmargin-right: 16px;
\t\t\tpadding: 2px 8px;
\t\t}
\t\t.dataTables_wrapper .dataTables_filter input{
\t\t\tborder: 1px solid #ccc;
\t\t\tbox-shadow: inset 0 1px 3px #F7F7F7;
\t\t\tpadding: 2px 8px;
\t\t\tborder-radius: 8px;
\t\t}
\t\t.card{
\t\t\tpadding: 1.5rem;
\t\t\tbox-shadow:  0px 3px 6px rgba(0,0,0,0.3);
\t\t\tborder-radius: 8px;
\t\t}
\t</style>
{% endblock %}

{% block javascripts %}
\t<script type=\"text/javascript\">
\t\tvar myApp = {
\t\t\tloadData: () => {
\t\t\t\t\$.ajax({            
\t\t            type: \"GET\",
\t\t            url: \"{{ constant('App\\\\Controller\\\\MainController::BASE_URL') }}public/data\",
\t\t            success: function(dataReturn){
\t\t            \tif( Array.isArray(dataReturn) ){
\t\t            \t\tvar tbody = '';
\t\t            \t\tfor(let i=0; i<dataReturn.length; i++){
\t\t            \t\t\tlet row = dataReturn[i];
\t\t            \t\t\ttbody += `\t<tr>
\t\t            \t\t\t\t\t\t\t<td>\${(i+1)}</td>
\t\t            \t\t\t\t\t\t\t<td>\${row.id}</td>
\t\t            \t\t\t\t\t\t\t<td>\${row.date}</td>
\t\t            \t\t\t\t\t\t\t<td class=\"text-right\">\${ accounting.formatMoney(row.total, \"AUD \", 2, \".\", \",\") }</td>
\t\t            \t\t\t\t\t\t\t<td class=\"text-right\">\${ accounting.formatMoney(row.avgPrice, \"AUD \", 2, \".\", \",\") }</td>
\t\t            \t\t\t\t\t\t\t<td>\${row.uniqueItem}</td>
\t\t            \t\t\t\t\t\t\t<td>\${row.state}</td>
\t\t            \t\t\t\t\t\t</tr>`;
\t\t            \t\t}
\t\t            \t}
\t\t                
\t\t\t\t\t\t\$(\"#tableOrder > tbody\").html(tbody);
\t\t\t\t\t\t\$(\"#tableOrder\").DataTable();
\t\t            \t
\t\t            },
\t\t            error: function(msg){
\t\t                alert(\"Some error occured, please try again later.\")
\t\t            }
\t\t        });
\t\t\t},
\t\t\tinit: () => {
\t\t\t\tmyApp.loadData();

\t\t\t\t\$(\"button[name='btnDownload']\").click( (e) => {
\t\t\t\t\tlet format = \$(e.target).data(\"fmt\");
\t\t\t\t\twindow.open( \"{{ constant('App\\\\Controller\\\\MainController::BASE_URL') }}public/download?format=\"+ format , \"_blank\");
\t\t\t\t});
\t\t\t}
\t\t}
\t\t\$(document).ready( () => {
\t\t\tmyApp.init();
\t\t});
\t</script>
{% endblock %}

{% block body %}
\t<div class=\"container-fluid p-3\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-lg-9\">
\t\t\t\t<div class=\"card\">
\t\t\t\t\t<h3>catch.com.au test</h3>
\t\t\t\t\t
\t\t\t\t\t<table class=\"table catch-table\" id=\"tableOrder\">
\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<th>No.</th>
\t\t\t\t\t\t\t\t<th>Order ID</th>
\t\t\t\t\t\t\t\t<th>Date Time</th>
\t\t\t\t\t\t\t\t<th>Total Order Value</th>
\t\t\t\t\t\t\t\t<th>Avg Unit Price</th>
\t\t\t\t\t\t\t\t<th>Unit Count</th>
\t\t\t\t\t\t\t\t<th>Customer State</th>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</thead>
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t
\t\t\t\t\t\t</tbody>
\t\t\t\t\t</table>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"col-lg-3\">
\t\t\t\t<div class=\"card\">
\t\t\t\t\t<h3 class=\"text-center border-bottom\">Get Data</h3>
\t\t\t\t\t<button name=\"btnDownload\" data-fmt=\"csv\" class=\"btn btn-primary m-1\">CSV</button>
\t\t\t\t\t<button name=\"btnDownload\" data-fmt=\"xml\" class=\"btn btn-primary m-1\">XML</button>
\t\t\t\t\t<button name=\"btnDownload\" data-fmt=\"json\" class=\"btn btn-primary m-1\">JSON</button>
\t\t\t\t</div>
\t\t\t</div>

\t\t</div>
\t</div>
\t
{% endblock %}", "catch.html.twig", "E:\\system\\xampp\\htdocs\\belajar\\symfony\\catch\\templates\\catch.html.twig");
    }
}
